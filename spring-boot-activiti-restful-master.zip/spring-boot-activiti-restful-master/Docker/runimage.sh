sudo docker run -p 8080:8080  -t -i smartkit/eip-activiti-single-image:latest 
