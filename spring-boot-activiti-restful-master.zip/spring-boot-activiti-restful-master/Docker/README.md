
### What?

### How?


```
docker pull smartkit/eip-activiti-single-image:v5
```

```
docker run -p 8080:8080  -t -i smartkit/eip-activiti-single-image:v5
```

```
http://loccalhost:8080/activiti-explorer
```

```
http://loccalhost:8080/activiti-rest
```

### Reference

#### LDAP

https://github.com/osixia/docker-openldap

#### Activiti
http://tech.blog.saeidmirzaei.com/

#### jasperReport
https://github.com/bitnami/bitnami-docker-jasperreports
