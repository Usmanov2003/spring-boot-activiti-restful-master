sudo docker build -t smartkit/eip-activiti_single_image:v1 .
