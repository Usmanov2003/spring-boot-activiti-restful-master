INSERT INTO test_user (name) VALUES ('Mr. T');

INSERT INTO test_user (name) VALUES ('Dr. No');