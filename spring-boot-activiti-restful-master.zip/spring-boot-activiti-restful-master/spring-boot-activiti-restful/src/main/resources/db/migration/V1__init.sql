CREATE TABLE test_user (

name VARCHAR(25) NOT NULL,

PRIMARY KEY(name)

);