package info.smartkit.eip.consts;

public class ThirdPartyConstants {
	final static public String DZDP_apiUrl = "http://api.dianping.com/v1/business/find_businesses";
	final static public String DZDP_appKey = "33331153";
	final static public String DZDP_secret = "f1ab2e9ab04a4959a1bf8cb5740bb598";
	//
	final static public String BAIDU_AK = "LusR3ViMWob3pqQTy1yfQfqA";
}
