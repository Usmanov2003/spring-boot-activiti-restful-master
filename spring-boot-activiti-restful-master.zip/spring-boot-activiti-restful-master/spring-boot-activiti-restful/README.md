## What? ##

Using SpringBoot framework to set up a RESTful API wrappering Activiti APIs.

And used Swagger-UI to visualize the RESTful API, And HTML5(Ionic) front-end interactive with APIs.

## How? ##

### Back-end ###

```
mvn spring-boot:run -Dspring.profiles.active=dev
```
